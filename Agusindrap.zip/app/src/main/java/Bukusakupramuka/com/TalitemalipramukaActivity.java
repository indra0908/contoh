package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class TalitemalipramukaActivity extends AppCompatActivity {
	
	
	private LinearLayout linear58;
	private LinearLayout linear1;
	private ScrollView vscroll2;
	private TextView textview1;
	private LinearLayout linear29;
	private LinearLayout linear60;
	private LinearLayout linear61;
	private LinearLayout linear62;
	private LinearLayout linear63;
	private LinearLayout linear64;
	private LinearLayout linear65;
	private LinearLayout linear66;
	private LinearLayout linear68;
	private LinearLayout linear69;
	private LinearLayout linear70;
	private LinearLayout linear71;
	private LinearLayout linear72;
	private LinearLayout linear73;
	private LinearLayout linear74;
	private LinearLayout linear75;
	private LinearLayout linear76;
	private LinearLayout linear77;
	private LinearLayout linear78;
	private LinearLayout linear79;
	private LinearLayout linear80;
	private LinearLayout linear81;
	private LinearLayout linear82;
	private LinearLayout linear83;
	private LinearLayout linear84;
	private LinearLayout linear85;
	private LinearLayout linear86;
	private LinearLayout linear87;
	private LinearLayout linear88;
	private LinearLayout linear91;
	private ImageView imageview41;
	private TextView textview30;
	private ImageView imageview64;
	private LinearLayout linear92;
	private ImageView imageview42;
	private TextView textview29;
	private ImageView imageview63;
	private LinearLayout linear93;
	private ImageView imageview43;
	private TextView textview27;
	private ImageView imageview62;
	private LinearLayout linear94;
	private ImageView imageview44;
	private TextView textview28;
	private ImageView imageview61;
	private LinearLayout linear95;
	private ImageView imageview46;
	private TextView textview25;
	private ImageView imageview60;
	private LinearLayout linear96;
	private ImageView imageview45;
	private TextView textview26;
	private ImageView imageview59;
	private LinearLayout linear97;
	private ImageView imageview47;
	private TextView textview24;
	private ImageView imageview58;
	private LinearLayout linear98;
	private ImageView imageview48;
	private TextView textview23;
	private ImageView imageview57;
	private LinearLayout linear99;
	private ImageView imageview49;
	private TextView textview22;
	private ImageView imageview56;
	private LinearLayout linear100;
	private ImageView imageview9;
	private TextView textview21;
	private ImageView imageview55;
	private LinearLayout linear101;
	private ImageView imageview8;
	private TextView textview20;
	private ImageView imageview54;
	private LinearLayout linear102;
	private ImageView imageview6;
	private TextView textview19;
	private ImageView imageview53;
	private LinearLayout linear103;
	private ImageView imageview4;
	private TextView textview18;
	private ImageView imageview52;
	private LinearLayout linear104;
	private ImageView imageview3;
	private TextView textview17;
	private ImageView imageview51;
	
	private Intent talitemali = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.talitemalipramuka);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear58 = (LinearLayout) findViewById(R.id.linear58);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear29 = (LinearLayout) findViewById(R.id.linear29);
		linear60 = (LinearLayout) findViewById(R.id.linear60);
		linear61 = (LinearLayout) findViewById(R.id.linear61);
		linear62 = (LinearLayout) findViewById(R.id.linear62);
		linear63 = (LinearLayout) findViewById(R.id.linear63);
		linear64 = (LinearLayout) findViewById(R.id.linear64);
		linear65 = (LinearLayout) findViewById(R.id.linear65);
		linear66 = (LinearLayout) findViewById(R.id.linear66);
		linear68 = (LinearLayout) findViewById(R.id.linear68);
		linear69 = (LinearLayout) findViewById(R.id.linear69);
		linear70 = (LinearLayout) findViewById(R.id.linear70);
		linear71 = (LinearLayout) findViewById(R.id.linear71);
		linear72 = (LinearLayout) findViewById(R.id.linear72);
		linear73 = (LinearLayout) findViewById(R.id.linear73);
		linear74 = (LinearLayout) findViewById(R.id.linear74);
		linear75 = (LinearLayout) findViewById(R.id.linear75);
		linear76 = (LinearLayout) findViewById(R.id.linear76);
		linear77 = (LinearLayout) findViewById(R.id.linear77);
		linear78 = (LinearLayout) findViewById(R.id.linear78);
		linear79 = (LinearLayout) findViewById(R.id.linear79);
		linear80 = (LinearLayout) findViewById(R.id.linear80);
		linear81 = (LinearLayout) findViewById(R.id.linear81);
		linear82 = (LinearLayout) findViewById(R.id.linear82);
		linear83 = (LinearLayout) findViewById(R.id.linear83);
		linear84 = (LinearLayout) findViewById(R.id.linear84);
		linear85 = (LinearLayout) findViewById(R.id.linear85);
		linear86 = (LinearLayout) findViewById(R.id.linear86);
		linear87 = (LinearLayout) findViewById(R.id.linear87);
		linear88 = (LinearLayout) findViewById(R.id.linear88);
		linear91 = (LinearLayout) findViewById(R.id.linear91);
		imageview41 = (ImageView) findViewById(R.id.imageview41);
		textview30 = (TextView) findViewById(R.id.textview30);
		imageview64 = (ImageView) findViewById(R.id.imageview64);
		linear92 = (LinearLayout) findViewById(R.id.linear92);
		imageview42 = (ImageView) findViewById(R.id.imageview42);
		textview29 = (TextView) findViewById(R.id.textview29);
		imageview63 = (ImageView) findViewById(R.id.imageview63);
		linear93 = (LinearLayout) findViewById(R.id.linear93);
		imageview43 = (ImageView) findViewById(R.id.imageview43);
		textview27 = (TextView) findViewById(R.id.textview27);
		imageview62 = (ImageView) findViewById(R.id.imageview62);
		linear94 = (LinearLayout) findViewById(R.id.linear94);
		imageview44 = (ImageView) findViewById(R.id.imageview44);
		textview28 = (TextView) findViewById(R.id.textview28);
		imageview61 = (ImageView) findViewById(R.id.imageview61);
		linear95 = (LinearLayout) findViewById(R.id.linear95);
		imageview46 = (ImageView) findViewById(R.id.imageview46);
		textview25 = (TextView) findViewById(R.id.textview25);
		imageview60 = (ImageView) findViewById(R.id.imageview60);
		linear96 = (LinearLayout) findViewById(R.id.linear96);
		imageview45 = (ImageView) findViewById(R.id.imageview45);
		textview26 = (TextView) findViewById(R.id.textview26);
		imageview59 = (ImageView) findViewById(R.id.imageview59);
		linear97 = (LinearLayout) findViewById(R.id.linear97);
		imageview47 = (ImageView) findViewById(R.id.imageview47);
		textview24 = (TextView) findViewById(R.id.textview24);
		imageview58 = (ImageView) findViewById(R.id.imageview58);
		linear98 = (LinearLayout) findViewById(R.id.linear98);
		imageview48 = (ImageView) findViewById(R.id.imageview48);
		textview23 = (TextView) findViewById(R.id.textview23);
		imageview57 = (ImageView) findViewById(R.id.imageview57);
		linear99 = (LinearLayout) findViewById(R.id.linear99);
		imageview49 = (ImageView) findViewById(R.id.imageview49);
		textview22 = (TextView) findViewById(R.id.textview22);
		imageview56 = (ImageView) findViewById(R.id.imageview56);
		linear100 = (LinearLayout) findViewById(R.id.linear100);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		textview21 = (TextView) findViewById(R.id.textview21);
		imageview55 = (ImageView) findViewById(R.id.imageview55);
		linear101 = (LinearLayout) findViewById(R.id.linear101);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		textview20 = (TextView) findViewById(R.id.textview20);
		imageview54 = (ImageView) findViewById(R.id.imageview54);
		linear102 = (LinearLayout) findViewById(R.id.linear102);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview19 = (TextView) findViewById(R.id.textview19);
		imageview53 = (ImageView) findViewById(R.id.imageview53);
		linear103 = (LinearLayout) findViewById(R.id.linear103);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview18 = (TextView) findViewById(R.id.textview18);
		imageview52 = (ImageView) findViewById(R.id.imageview52);
		linear104 = (LinearLayout) findViewById(R.id.linear104);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview17 = (TextView) findViewById(R.id.textview17);
		imageview51 = (ImageView) findViewById(R.id.imageview51);
		
		linear91.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulhidupActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear92.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulmatiActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear93.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulpangkalActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear94.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpuljangkarActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear95.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulanyamActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear96.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulanyambergandaActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear97.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulrantaiActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear98.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulkembarActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear99.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpultambatActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear100.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpuleratActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear101.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulkursiActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear102.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpultiangActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear103.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulprusikActivity.class);
				startActivity(talitemali);
			}
		});
		
		linear104.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				talitemali.setClass(getApplicationContext(), SimpulpenarikActivity.class);
				startActivity(talitemali);
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
