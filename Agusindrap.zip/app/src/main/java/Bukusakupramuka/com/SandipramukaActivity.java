package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class SandipramukaActivity extends AppCompatActivity {
	
	
	private LinearLayout linear41;
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private TextView textview18;
	private LinearLayout linear2;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout linear29;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private LinearLayout linear33;
	private LinearLayout linear34;
	private LinearLayout linear35;
	private LinearLayout linear36;
	private LinearLayout linear37;
	private LinearLayout linear38;
	private LinearLayout linear39;
	private LinearLayout linear42;
	private LinearLayout linear43;
	private LinearLayout linear44;
	private LinearLayout linear45;
	private LinearLayout linear46;
	private LinearLayout linear47;
	private LinearLayout linear48;
	private LinearLayout linear49;
	private LinearLayout linear50;
	private LinearLayout linear51;
	private LinearLayout linear52;
	private LinearLayout linear53;
	private LinearLayout linear19;
	private LinearLayout linear70;
	private ImageView imageview33;
	private TextView textview33;
	private ImageView imageview44;
	private LinearLayout linear69;
	private ImageView imageview34;
	private TextView textview34;
	private ImageView imageview45;
	private LinearLayout linear68;
	private ImageView imageview35;
	private TextView textview32;
	private ImageView imageview46;
	private LinearLayout linear67;
	private ImageView imageview36;
	private TextView textview30;
	private ImageView imageview47;
	private LinearLayout linear66;
	private ImageView imageview37;
	private TextView textview31;
	private ImageView imageview48;
	private LinearLayout linear65;
	private ImageView imageview38;
	private TextView textview28;
	private ImageView imageview49;
	private LinearLayout linear64;
	private ImageView imageview39;
	private TextView textview29;
	private ImageView imageview50;
	private LinearLayout linear63;
	private ImageView imageview40;
	private TextView textview27;
	private ImageView imageview51;
	private LinearLayout linear62;
	private ImageView imageview41;
	private TextView textview26;
	private ImageView imageview52;
	private LinearLayout linear61;
	private ImageView imageview42;
	private TextView textview25;
	private ImageView imageview53;
	private LinearLayout linear60;
	private ImageView imageview43;
	private TextView textview24;
	private ImageView imageview54;
	private LinearLayout linear59;
	private ImageView imageview16;
	private TextView textview23;
	private ImageView imageview55;
	private LinearLayout linear58;
	private ImageView imageview4;
	private TextView textview22;
	private ImageView imageview56;
	private LinearLayout linear57;
	private ImageView imageview3;
	private TextView textview21;
	private ImageView imageview57;
	private LinearLayout linear56;
	private ImageView imageview2;
	private TextView textview20;
	private ImageView imageview58;
	private LinearLayout linear55;
	private ImageView imageview1;
	private TextView textview19;
	private ImageView imageview59;
	
	private Intent sandisandipramuka = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sandipramuka);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear41 = (LinearLayout) findViewById(R.id.linear41);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		textview18 = (TextView) findViewById(R.id.textview18);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		linear25 = (LinearLayout) findViewById(R.id.linear25);
		linear26 = (LinearLayout) findViewById(R.id.linear26);
		linear27 = (LinearLayout) findViewById(R.id.linear27);
		linear28 = (LinearLayout) findViewById(R.id.linear28);
		linear29 = (LinearLayout) findViewById(R.id.linear29);
		linear30 = (LinearLayout) findViewById(R.id.linear30);
		linear31 = (LinearLayout) findViewById(R.id.linear31);
		linear32 = (LinearLayout) findViewById(R.id.linear32);
		linear33 = (LinearLayout) findViewById(R.id.linear33);
		linear34 = (LinearLayout) findViewById(R.id.linear34);
		linear35 = (LinearLayout) findViewById(R.id.linear35);
		linear36 = (LinearLayout) findViewById(R.id.linear36);
		linear37 = (LinearLayout) findViewById(R.id.linear37);
		linear38 = (LinearLayout) findViewById(R.id.linear38);
		linear39 = (LinearLayout) findViewById(R.id.linear39);
		linear42 = (LinearLayout) findViewById(R.id.linear42);
		linear43 = (LinearLayout) findViewById(R.id.linear43);
		linear44 = (LinearLayout) findViewById(R.id.linear44);
		linear45 = (LinearLayout) findViewById(R.id.linear45);
		linear46 = (LinearLayout) findViewById(R.id.linear46);
		linear47 = (LinearLayout) findViewById(R.id.linear47);
		linear48 = (LinearLayout) findViewById(R.id.linear48);
		linear49 = (LinearLayout) findViewById(R.id.linear49);
		linear50 = (LinearLayout) findViewById(R.id.linear50);
		linear51 = (LinearLayout) findViewById(R.id.linear51);
		linear52 = (LinearLayout) findViewById(R.id.linear52);
		linear53 = (LinearLayout) findViewById(R.id.linear53);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear70 = (LinearLayout) findViewById(R.id.linear70);
		imageview33 = (ImageView) findViewById(R.id.imageview33);
		textview33 = (TextView) findViewById(R.id.textview33);
		imageview44 = (ImageView) findViewById(R.id.imageview44);
		linear69 = (LinearLayout) findViewById(R.id.linear69);
		imageview34 = (ImageView) findViewById(R.id.imageview34);
		textview34 = (TextView) findViewById(R.id.textview34);
		imageview45 = (ImageView) findViewById(R.id.imageview45);
		linear68 = (LinearLayout) findViewById(R.id.linear68);
		imageview35 = (ImageView) findViewById(R.id.imageview35);
		textview32 = (TextView) findViewById(R.id.textview32);
		imageview46 = (ImageView) findViewById(R.id.imageview46);
		linear67 = (LinearLayout) findViewById(R.id.linear67);
		imageview36 = (ImageView) findViewById(R.id.imageview36);
		textview30 = (TextView) findViewById(R.id.textview30);
		imageview47 = (ImageView) findViewById(R.id.imageview47);
		linear66 = (LinearLayout) findViewById(R.id.linear66);
		imageview37 = (ImageView) findViewById(R.id.imageview37);
		textview31 = (TextView) findViewById(R.id.textview31);
		imageview48 = (ImageView) findViewById(R.id.imageview48);
		linear65 = (LinearLayout) findViewById(R.id.linear65);
		imageview38 = (ImageView) findViewById(R.id.imageview38);
		textview28 = (TextView) findViewById(R.id.textview28);
		imageview49 = (ImageView) findViewById(R.id.imageview49);
		linear64 = (LinearLayout) findViewById(R.id.linear64);
		imageview39 = (ImageView) findViewById(R.id.imageview39);
		textview29 = (TextView) findViewById(R.id.textview29);
		imageview50 = (ImageView) findViewById(R.id.imageview50);
		linear63 = (LinearLayout) findViewById(R.id.linear63);
		imageview40 = (ImageView) findViewById(R.id.imageview40);
		textview27 = (TextView) findViewById(R.id.textview27);
		imageview51 = (ImageView) findViewById(R.id.imageview51);
		linear62 = (LinearLayout) findViewById(R.id.linear62);
		imageview41 = (ImageView) findViewById(R.id.imageview41);
		textview26 = (TextView) findViewById(R.id.textview26);
		imageview52 = (ImageView) findViewById(R.id.imageview52);
		linear61 = (LinearLayout) findViewById(R.id.linear61);
		imageview42 = (ImageView) findViewById(R.id.imageview42);
		textview25 = (TextView) findViewById(R.id.textview25);
		imageview53 = (ImageView) findViewById(R.id.imageview53);
		linear60 = (LinearLayout) findViewById(R.id.linear60);
		imageview43 = (ImageView) findViewById(R.id.imageview43);
		textview24 = (TextView) findViewById(R.id.textview24);
		imageview54 = (ImageView) findViewById(R.id.imageview54);
		linear59 = (LinearLayout) findViewById(R.id.linear59);
		imageview16 = (ImageView) findViewById(R.id.imageview16);
		textview23 = (TextView) findViewById(R.id.textview23);
		imageview55 = (ImageView) findViewById(R.id.imageview55);
		linear58 = (LinearLayout) findViewById(R.id.linear58);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview22 = (TextView) findViewById(R.id.textview22);
		imageview56 = (ImageView) findViewById(R.id.imageview56);
		linear57 = (LinearLayout) findViewById(R.id.linear57);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview21 = (TextView) findViewById(R.id.textview21);
		imageview57 = (ImageView) findViewById(R.id.imageview57);
		linear56 = (LinearLayout) findViewById(R.id.linear56);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview20 = (TextView) findViewById(R.id.textview20);
		imageview58 = (ImageView) findViewById(R.id.imageview58);
		linear55 = (LinearLayout) findViewById(R.id.linear55);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview19 = (TextView) findViewById(R.id.textview19);
		imageview59 = (ImageView) findViewById(R.id.imageview59);
		
		linear70.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), Skotak1Activity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear69.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), Skotak2Activity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear68.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), Skotak3Activity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear67.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandianActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear66.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandiazActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear65.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandiandActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear64.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandinapoleonActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear63.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandiangkaActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear62.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandimorseActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear61.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandirumputActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear60.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandikoordinatActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear59.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandijamActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear58.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandidatarActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear57.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandipanasdinginActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear56.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandibrailleActivity.class);
				startActivity(sandisandipramuka);
			}
		});
		
		linear55.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sandisandipramuka.setClass(getApplicationContext(), SandikimiaActivity.class);
				startActivity(sandisandipramuka);
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
