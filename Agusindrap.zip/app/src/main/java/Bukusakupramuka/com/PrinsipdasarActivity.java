package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PrinsipdasarActivity extends AppCompatActivity {
	
	
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private TextView textview4;
	private TextView textview3;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.prinsipdasar);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview3 = (TextView) findViewById(R.id.textview3);
	}
	private void initializeLogic() {
		textview3.setText("   Prinsip Dasar dan Metode Kepramukaan Prinsip Dasar dan Metode Kepramukaan merupakan prinsip yang digunakan dalam pendidikan kepramukaan, yang membedakannya dengan gerakan pendidikan lainnya. Baden-Powell sebagai penemu sistem pendidikan kepanduan telah menyusun prinsip-prinsip Dasar dan Metode Kepanduan, lalu menggunakannya untuk membina generasi muda melalui pendidikan kepanduan. Beberapa prinsip itu didasarkan pada kegiatan anak atau remaja sehari-hari. Prinsip Dasar dan Metode Kepanduan itu harus diterapkan secara menyeluruh. Bila sebagian dari prinsip itu dihilangkan, maka organisasi itu bukan lagi gerakan pendidikan kepanduan. Dalam Anggaran dasar Gerakan Pramuka dinyatakan bahwa Prinsip Dasar dan Metode Kepramukaan bertumpu pada:\n\n• Keimanan dan ketakwaan kepada Tuhan Yang Maha Esa;\n\n• Kepedulian terhadap bangsa dan tanah air, sesama hidup dan alam seisinya;\n\n• Kepedulian terhadap diri pribadinya;\n\n• Ketaatan kepada Kode Kehormatan Pramuka.\n\n   Prinsip dasar Prinsip Dasar Kepramukaan sebagai norma hidup seorang anggota Gerakan Pramuka, ditanamkan dan ditumbuhkembangkan melalui proses penghayatan oleh dan untuk diri pribadinya dengan dibantu oleh pembina, sehingga pelaksanaan dan pengamalannya dilakukan dengan penuh kesadaran, kemandirian, kepedulian, tanggung jawab serta keterikatan moral, baik sebagai pribadi maupun anggota masyarakat. Metode Metode Kepramukaan merupakan cara belajar progresif melalui :\n\n• Pengamalan Kode Kehormatan Pramuka;\n\n• Belajar sambil melakukan;\n\n• Sistem berkelompok;\n\n• Kegiatan yang menantang dan meningkat serta mengandung pendidikan yang sesuai dengan Perkembangan rohani dan jasmani pesertadidik;\n\n• Kegiatan di alam terbuka;\n\n• Sistem tanda kecakapan;\n\n• Sistem satuan terpisah untuk putera dan untuk puteri;\n\n• Sistem among. Metode Kepramukaan pada hakikatnya tidak dapat dilepaskan dari Prinsip Dasar Kepramukaan.\n\n   Keterkaitan itu terletak pada pelaksanaan Kode Kehormatan. Metode Kepramukaan juga digunakan sebagai sebagai suatu sistem yang terdiri atas unsur-unsur yang merupakan subsistem terpadu dan terkait, yang tiap unsurnya mempunyai fungsi pendidikan yang spesifik dan saling memperkuat serta menunjang tercapainya tujuan.\n\n\n");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
