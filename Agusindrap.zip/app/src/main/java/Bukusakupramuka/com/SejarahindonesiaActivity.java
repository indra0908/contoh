package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SejarahindonesiaActivity extends AppCompatActivity {
	
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TextView textview1;
	private TextView textview2;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sejarahindonesia);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
	}
	private void initializeLogic() {
		textview2.setText("   Sejarah gerakan pramuka di Indonesia dimulai sejak tahun 1912. Cikal bakal pramuka Indonesia adalah didirikannya organisasi Nederlandsche Padvinders Organisatie (NPO) bentukan Belanda. Kemudian pada tahun 1916, organisasi tersebut berganti nama menjadi Nederlands-Indische Padviders Vereeniging (NIPV).\n\n   Istilah Padvinders merujuk kepada istilah untuk organisasi Pramuka yang ada di negeri Belanda. Penggunaan istilah Padvindery kemudian sempat mendapat larangan dari Belanda. Para tokoh nasional Indonesia kemudian mengganti istilah Padvindery dengan Pandu atau Kepanduan.\n   Pada tahun 1916, dibentuklah organisasi kepemudaan bentukan bangsa Indonesia bernama Javaansche Padviders Organisatie yang diprakarsai oleh S.P. Mangkunegara VII. Usai peristiwa Sumpah Pemuda, kian banyak organisasi kepanduan yang dibentuk, baik bernafaskan nasionalis atau keagamaan, beberapa di antaranya adalah:\n   Padvinder Muhammadiyah, kemudian berganti nama menjadi Hizbul Wathan (HW). Nationale Padvinderij yang didirikan Budi Utomo. Syarikat Islam Afdeling Padvinderij (SIAP) yang didirikan Syarikat Islam. Nationale Islamietische Padvinderij (NATIPIJ) yang didirikan oleh Jong Islamieten Bond. Indonesisch Nationale Padvinders Organisatie (INPO) yang didirikan oleh Pemuda Indonesia\n\n   Banyaknya organisasi kepanduan Indonesia membuat dibentuklah Persaudaraan Antara Pandu Indonesia (PAPI) pada tanggal 23 Mei 1928, yang mewadahi organisasi-organisasi tersebut. Pada 1930, PAPI melebur menjadi Kepanduan Bangsa Indonesia (KBI) yang dirintis oleh tokoh-tokoh organisasi lain.\n\n   PAPI kemudian berkembang menjadi Badan Pusat Persaudaraan Kepanduan Indonesia (BPPKI) pada bulan April 1938. Untuk menggalang kesatuan dan persatuan, BPPKI mengadakan “Perkemahan Kepanduan Indonesia Oemoem” disingkat PERKINO dan dilaksanakan pada tanggal 19-23 Juli 1941 di Yogyakarta.\n\n   Saat masa penjajahan Jepang, gerakan kepanduan sempat dilarang untuk bediri. Meski begitu semangat kepanduan tetap menyala di dada para anggotanya. Barulah usai proklamasi kemerdekaan, tokoh kepanduan Indonesia membentuk Panitia Kesatuan Kepanduan Indonesia untuk pembentukan satu wadah organisasi kepanduan di Indonesia.\n\n   Diadakanlah Kongres Kesatuan Kepanduan Indonesia pada tanggal 27-29 Desember 1945 di Surakarta dengan hasil terbentuknya Pandu Rakyat Indonesia, yang kemudian diakui pemerintah sebagai satu-satunya organisasi kepanduan lewat keputusan Menteri Pendidikan, Pengajaran dan Kebudayaan pada 1 Februari 1947.\n\n   Pada akhirnya, keputusan tersebut dianulir sehingga kelompok lain bisa membuka organisasi kepanduan baru dan Pandu Rakyat Indonesia bukan lagi satu-satunya organisasi kepanduan di Indonesia. Di awal 60an, diperkirakan ada lebih dari 100 organisasi kepanduan di Indonesia.\n\n   Keseluruhan organisasi kepanduan yang ada bernaung pada 3 federasi utama, yakni Ikatan Pandu Indonesia (IPINDO) bagi anggota pandu pria serta PKPI (Persatuan Kepanduan Puteri Indonesia) dan POPPINDO (Persatuan Organisasi Pandu Puteri Indonesia) untuk organisasi pandu wanita.\n\n   Baru pada tahun 1961, Gerakan Pramuka akhirnya lahir. Hal ini dilatarbelakangi kian banyaknya organisasi kepanduan yang ada. Pada tanggal 14 Agustus 1961, dilakukan pelantikan Mapinas, Kwarnas dan Kwarnari di Istana Negara, serta penganugerahan Panji-Panji Gerakan Pramuka. Tanggal 14 Agustus kemudian diperingati sebagai Hari Pramuka.\n");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
