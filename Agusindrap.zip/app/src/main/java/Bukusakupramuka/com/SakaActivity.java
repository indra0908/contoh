package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class SakaActivity extends AppCompatActivity {
	
	
	private LinearLayout linear15;
	private LinearLayout linear16;
	private ScrollView vscroll2;
	private TextView textview14;
	private LinearLayout linear17;
	private LinearLayout linear36;
	private LinearLayout linear37;
	private LinearLayout linear38;
	private LinearLayout linear39;
	private LinearLayout linear40;
	private LinearLayout linear41;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout linear22;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout linear29;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private LinearLayout linear33;
	private LinearLayout linear34;
	private LinearLayout linear35;
	private LinearLayout linear42;
	private ImageView imageview13;
	private TextView textview15;
	private ImageView imageview25;
	private LinearLayout linear43;
	private ImageView imageview12;
	private TextView textview16;
	private ImageView imageview24;
	private LinearLayout linear44;
	private ImageView imageview11;
	private TextView textview17;
	private ImageView imageview23;
	private LinearLayout linear45;
	private ImageView imageview9;
	private TextView textview18;
	private ImageView imageview22;
	private LinearLayout linear46;
	private ImageView imageview10;
	private TextView textview19;
	private ImageView imageview21;
	private LinearLayout linear47;
	private ImageView imageview8;
	private TextView textview20;
	private ImageView imageview20;
	private LinearLayout linear48;
	private ImageView imageview7;
	private TextView textview21;
	private ImageView imageview19;
	private LinearLayout linear49;
	private ImageView imageview6;
	private TextView textview22;
	private ImageView imageview18;
	private LinearLayout linear50;
	private ImageView imageview5;
	private TextView textview23;
	private ImageView imageview17;
	private LinearLayout linear51;
	private ImageView imageview4;
	private TextView textview24;
	private ImageView imageview16;
	private LinearLayout linear52;
	private ImageView imageview3;
	private TextView textview25;
	private ImageView imageview15;
	private LinearLayout linear53;
	private ImageView imageview2;
	private TextView textview26;
	private ImageView imageview14;
	
	private Intent saka = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.saka);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		textview14 = (TextView) findViewById(R.id.textview14);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear36 = (LinearLayout) findViewById(R.id.linear36);
		linear37 = (LinearLayout) findViewById(R.id.linear37);
		linear38 = (LinearLayout) findViewById(R.id.linear38);
		linear39 = (LinearLayout) findViewById(R.id.linear39);
		linear40 = (LinearLayout) findViewById(R.id.linear40);
		linear41 = (LinearLayout) findViewById(R.id.linear41);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		linear22 = (LinearLayout) findViewById(R.id.linear22);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		linear25 = (LinearLayout) findViewById(R.id.linear25);
		linear26 = (LinearLayout) findViewById(R.id.linear26);
		linear27 = (LinearLayout) findViewById(R.id.linear27);
		linear28 = (LinearLayout) findViewById(R.id.linear28);
		linear29 = (LinearLayout) findViewById(R.id.linear29);
		linear30 = (LinearLayout) findViewById(R.id.linear30);
		linear31 = (LinearLayout) findViewById(R.id.linear31);
		linear32 = (LinearLayout) findViewById(R.id.linear32);
		linear33 = (LinearLayout) findViewById(R.id.linear33);
		linear34 = (LinearLayout) findViewById(R.id.linear34);
		linear35 = (LinearLayout) findViewById(R.id.linear35);
		linear42 = (LinearLayout) findViewById(R.id.linear42);
		imageview13 = (ImageView) findViewById(R.id.imageview13);
		textview15 = (TextView) findViewById(R.id.textview15);
		imageview25 = (ImageView) findViewById(R.id.imageview25);
		linear43 = (LinearLayout) findViewById(R.id.linear43);
		imageview12 = (ImageView) findViewById(R.id.imageview12);
		textview16 = (TextView) findViewById(R.id.textview16);
		imageview24 = (ImageView) findViewById(R.id.imageview24);
		linear44 = (LinearLayout) findViewById(R.id.linear44);
		imageview11 = (ImageView) findViewById(R.id.imageview11);
		textview17 = (TextView) findViewById(R.id.textview17);
		imageview23 = (ImageView) findViewById(R.id.imageview23);
		linear45 = (LinearLayout) findViewById(R.id.linear45);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		textview18 = (TextView) findViewById(R.id.textview18);
		imageview22 = (ImageView) findViewById(R.id.imageview22);
		linear46 = (LinearLayout) findViewById(R.id.linear46);
		imageview10 = (ImageView) findViewById(R.id.imageview10);
		textview19 = (TextView) findViewById(R.id.textview19);
		imageview21 = (ImageView) findViewById(R.id.imageview21);
		linear47 = (LinearLayout) findViewById(R.id.linear47);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		textview20 = (TextView) findViewById(R.id.textview20);
		imageview20 = (ImageView) findViewById(R.id.imageview20);
		linear48 = (LinearLayout) findViewById(R.id.linear48);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview21 = (TextView) findViewById(R.id.textview21);
		imageview19 = (ImageView) findViewById(R.id.imageview19);
		linear49 = (LinearLayout) findViewById(R.id.linear49);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview22 = (TextView) findViewById(R.id.textview22);
		imageview18 = (ImageView) findViewById(R.id.imageview18);
		linear50 = (LinearLayout) findViewById(R.id.linear50);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview23 = (TextView) findViewById(R.id.textview23);
		imageview17 = (ImageView) findViewById(R.id.imageview17);
		linear51 = (LinearLayout) findViewById(R.id.linear51);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview24 = (TextView) findViewById(R.id.textview24);
		imageview16 = (ImageView) findViewById(R.id.imageview16);
		linear52 = (LinearLayout) findViewById(R.id.linear52);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview25 = (TextView) findViewById(R.id.textview25);
		imageview15 = (ImageView) findViewById(R.id.imageview15);
		linear53 = (LinearLayout) findViewById(R.id.linear53);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview26 = (TextView) findViewById(R.id.textview26);
		imageview14 = (ImageView) findViewById(R.id.imageview14);
		
		linear42.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakabhayangkaraActivity.class);
				startActivity(saka);
			}
		});
		
		linear43.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakawirakartikaActivity.class);
				startActivity(saka);
			}
		});
		
		linear44.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakabahariActivity.class);
				startActivity(saka);
			}
		});
		
		linear45.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakawanabaktiActivity.class);
				startActivity(saka);
			}
		});
		
		linear46.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakabaktihusadaActivity.class);
				startActivity(saka);
			}
		});
		
		linear47.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakadirgantaraActivity.class);
				startActivity(saka);
			}
		});
		
		linear48.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakakencanaActivity.class);
				startActivity(saka);
			}
		});
		
		linear49.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakatarunabumiActivity.class);
				startActivity(saka);
			}
		});
		
		linear50.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakabinasosialActivity.class);
				startActivity(saka);
			}
		});
		
		linear51.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakapanduwisataActivity.class);
				startActivity(saka);
			}
		});
		
		linear52.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakatelematikaActivity.class);
				startActivity(saka);
			}
		});
		
		linear53.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				saka.setClass(getApplicationContext(), SakapustakaActivity.class);
				startActivity(saka);
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
