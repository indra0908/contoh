package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;

public class LambangpramukaActivity extends AppCompatActivity {
	
	
	private LinearLayout linear2;
	private ScrollView vscroll2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private TextView textview1;
	private ImageView imageview1;
	private TextView textview2;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.lambangpramuka);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview2 = (TextView) findViewById(R.id.textview2);
	}
	private void initializeLogic() {
		textview2.setText("   Lambang Gerakan adalah Tanda pengenal tetap yang mengkiaskan cita-cita setiap anggota\n\nBentuk\n   Gerakan Pramuka Lambang Gerakan Pramuka berbentuk / berupa Silluete Tunas Kelapa. (lihat gambar di samping) Penjabaran tentang Lambang ini ditetapkan dalam SK Kwarnas Nomer 06/KN/72 tentang Lambang Gerakan Pramuka.\n\nArti kiasan\n   Lambang Gerakan Pramuka mengandung arti kiasan sebagai berikut:\n\n1. Buah nyiur dalam keadaan tumbuh dinamakan cikal. Ini mengandung arti Pramuka adalah inti bagi kelangsungan hidup bangsa (tunas penerus bangsa).\n\n2. Buah nyiur tahan lama. Ini mengandung arti, Pramuka adalah orang yang jasmani dan rohaninya kuat dan ulet.\n\n3. Nyiur dapat tumbuh dimana saja. Ini mengandung arti, Pramuka adalah orang yang mampu beradaptasi dalam kondisi apapun\n\n4. Nyiur tumbuh menjulang tinggi. Ini mengandung arti, setiap Pramuka memiliki cita-cita yang tinggi.\n\n5. Akar nyiur kuat. Mengandung arti, Pramuka berpegang pada dasar-dasar yang kuat.\n\n6. Nyiur pohon yang serbaguna. Ini mengandung arti, Pramuka berguna bagi nusa, bangsa dan agama.\n\n7. Lambang keris melambangkan senjata tradisional Jawa Tengah\n\n8. Lambang 10 api yang berkobar melambangkan dasadarma\n\n9. Padi dan kapas melambangkan kesuburan dibidang pangan dan sandang\n\n9. Kode daerah melambangkan daerah kota daerah\n\n10. Nama kabupaten melambangkan kota cabang\n\n11. Bintang melambangakan 5 sila pancasila\n\nPenggunaan\n   Lambang Gerakan Pramuka dapat dipergunakan pada Panji, Bendera, Papan Nama Kwartir / Satuan, Tanda Pengenal dan alat administrasi Gerakan Pramuka. Penggunaan lambang tersebut dimaksudkan sebagai alat pendidikan untuk mengingatkan dan menanamkan sifat dan keadaan seperti yang termaktub dalam arti kiasan lambang Tunas Kelapa itu pada setiap anggota Gerakan Pramuka.\n\n   Setiap anggota Gerakan Pramuka diharapkan mampu mengamalkan dan mempraktekkan ilmu pengetahuan dan teknologi yang dimilikinya kepada masyarakat di sekelilingnya. Sebab generasi muda yang tergabung dalam Gerakan Pramuka diharapkan kelak mampu menjadi kader pembangunan yang berjiwa Pancasila.\n\n");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
