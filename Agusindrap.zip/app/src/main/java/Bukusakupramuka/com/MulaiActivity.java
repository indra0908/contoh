package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class MulaiActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	
	private LinearLayout linear1;
	private LinearLayout linear15;
	private LinearLayout linear37;
	private ScrollView vscroll1;
	private LinearLayout linear38;
	private LinearLayout linear39;
	private LinearLayout linear40;
	private LinearLayout linear41;
	private LinearLayout linear42;
	private LinearLayout linear43;
	private LinearLayout linear44;
	private LinearLayout linear45;
	private LinearLayout linear46;
	private LinearLayout linear47;
	private LinearLayout linear48;
	private LinearLayout linear49;
	private LinearLayout linear50;
	private LinearLayout linear51;
	private LinearLayout linear52;
	private LinearLayout linear53;
	private LinearLayout linear54;
	private LinearLayout linear55;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView imageview17;
	private LinearLayout linear56;
	private ImageView imageview2;
	private TextView textview2;
	private ImageView imageview16;
	private LinearLayout linear57;
	private ImageView imageview3;
	private TextView textview3;
	private ImageView imageview15;
	private LinearLayout linear58;
	private ImageView imageview5;
	private TextView textview4;
	private ImageView imageview14;
	private LinearLayout linear59;
	private ImageView imageview4;
	private TextView textview5;
	private ImageView imageview13;
	private LinearLayout linear60;
	private ImageView imageview6;
	private TextView textview6;
	private ImageView imageview12;
	private LinearLayout linear61;
	private ImageView imageview7;
	private TextView textview7;
	private ImageView imageview11;
	private LinearLayout linear62;
	private ImageView imageview8;
	private TextView textview8;
	private ImageView imageview10;
	
	private Intent mainhalamanpndanumum = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.mulai);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear37 = (LinearLayout) findViewById(R.id.linear37);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear38 = (LinearLayout) findViewById(R.id.linear38);
		linear39 = (LinearLayout) findViewById(R.id.linear39);
		linear40 = (LinearLayout) findViewById(R.id.linear40);
		linear41 = (LinearLayout) findViewById(R.id.linear41);
		linear42 = (LinearLayout) findViewById(R.id.linear42);
		linear43 = (LinearLayout) findViewById(R.id.linear43);
		linear44 = (LinearLayout) findViewById(R.id.linear44);
		linear45 = (LinearLayout) findViewById(R.id.linear45);
		linear46 = (LinearLayout) findViewById(R.id.linear46);
		linear47 = (LinearLayout) findViewById(R.id.linear47);
		linear48 = (LinearLayout) findViewById(R.id.linear48);
		linear49 = (LinearLayout) findViewById(R.id.linear49);
		linear50 = (LinearLayout) findViewById(R.id.linear50);
		linear51 = (LinearLayout) findViewById(R.id.linear51);
		linear52 = (LinearLayout) findViewById(R.id.linear52);
		linear53 = (LinearLayout) findViewById(R.id.linear53);
		linear54 = (LinearLayout) findViewById(R.id.linear54);
		linear55 = (LinearLayout) findViewById(R.id.linear55);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview17 = (ImageView) findViewById(R.id.imageview17);
		linear56 = (LinearLayout) findViewById(R.id.linear56);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview16 = (ImageView) findViewById(R.id.imageview16);
		linear57 = (LinearLayout) findViewById(R.id.linear57);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview15 = (ImageView) findViewById(R.id.imageview15);
		linear58 = (LinearLayout) findViewById(R.id.linear58);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview14 = (ImageView) findViewById(R.id.imageview14);
		linear59 = (LinearLayout) findViewById(R.id.linear59);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		imageview13 = (ImageView) findViewById(R.id.imageview13);
		linear60 = (LinearLayout) findViewById(R.id.linear60);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview6 = (TextView) findViewById(R.id.textview6);
		imageview12 = (ImageView) findViewById(R.id.imageview12);
		linear61 = (LinearLayout) findViewById(R.id.linear61);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview7 = (TextView) findViewById(R.id.textview7);
		imageview11 = (ImageView) findViewById(R.id.imageview11);
		linear62 = (LinearLayout) findViewById(R.id.linear62);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		textview8 = (TextView) findViewById(R.id.textview8);
		imageview10 = (ImageView) findViewById(R.id.imageview10);
		
		linear55.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mainhalamanpndanumum.setClass(getApplicationContext(), PanduanumumActivity.class);
				startActivity(mainhalamanpndanumum);
			}
		});
		
		linear56.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mainhalamanpndanumum.setClass(getApplicationContext(), SejarahpramukaActivity.class);
				startActivity(mainhalamanpndanumum);
			}
		});
		
		linear57.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mainhalamanpndanumum.setClass(getApplicationContext(), MateripramukaActivity.class);
				startActivity(mainhalamanpndanumum);
			}
		});
		
		linear58.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mainhalamanpndanumum.setClass(getApplicationContext(), TingkatanpramukaActivity.class);
				startActivity(mainhalamanpndanumum);
			}
		});
		
		linear59.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mainhalamanpndanumum.setClass(getApplicationContext(), SandipramukaActivity.class);
				startActivity(mainhalamanpndanumum);
			}
		});
		
		linear60.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mainhalamanpndanumum.setClass(getApplicationContext(), TalitemalipramukaActivity.class);
				startActivity(mainhalamanpndanumum);
			}
		});
		
		linear61.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mainhalamanpndanumum.setClass(getApplicationContext(), SemaphoreActivity.class);
				startActivity(mainhalamanpndanumum);
			}
		});
		
		linear62.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mainhalamanpndanumum.setClass(getApplicationContext(), SakaActivity.class);
				startActivity(mainhalamanpndanumum);
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
