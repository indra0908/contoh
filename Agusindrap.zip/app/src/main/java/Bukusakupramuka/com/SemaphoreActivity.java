package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;

public class SemaphoreActivity extends AppCompatActivity {
	
	
	private LinearLayout linear3;
	private LinearLayout linear4;
	private ScrollView vscroll2;
	private TextView textview7;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private TextView textview6;
	private ImageView imageview4;
	private TextView textview8;
	private ImageView imageview5;
	private TextView textview9;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.semaphore);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		textview6 = (TextView) findViewById(R.id.textview6);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview8 = (TextView) findViewById(R.id.textview8);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview9 = (TextView) findViewById(R.id.textview9);
	}
	private void initializeLogic() {
		textview6.setText("Semaphore\n   Adalah salah satu teknik untuk menyampaikan dan menerima pesan dengan jarak yang berjauhan. Semaphore digunakan jika keadaan tidak memungkinkan untuk berkomunikasi secara langsung maupun dengan alat komunikasi lainnya. Dalam kepramukaan teknik semaphore biasa dilakukan dengan menggunakan sepasang bendera yang memiliki ukuran 45cm x 45cm yang merupakan gabungan dua buah segitiga sama kaki yang masing-masing berwarna merah dan kuning. Pemilihan warna ini disengaja karena warna ini terlihat mencolok walaupun terlihat dari jarak yang sangat jauh.");
		textview8.setText("Berikut Pergerakan dalam Semaphore :");
		textview9.setText("Cara mengirim dan menerima berita dalam semaphore adalah sebagai berikut:\n\n1. Usahakan untuk mengirim atau menerima berita berada di tempat yang terang.\n\n2. Untuk pengirim sebaiknya dilakukan oleh dua orang atau tiga orang, satu sebagai pengirim isyarat, satu sebagai pembaca isyarat dan satu lagi sebagai pembawa kunci kode isyarat jika belum hafal\n\n3. Sikap pengirim tegak, dan dua orang lainnya jongkok tanpa menghalangi si pengirim.\n\n4. Sebelum mengirim berita , kirim perhatian kepada si penerima. Jika siap penerima menjawab dengan “K”\n\n5. Kirimkan hurufperhuruf dari tiap perkataan.\n\n6. Untuk menyatakan perkataan telah selesai dipakai tanda bendera dipegang bersilang kebawah dan juga digunakan kalau ada huruf kembar.\n\n7. Jika tiap perkataan diterima dengan baik penerima menyatakan dengan mengirim huruf “C”\n\n8. Bila pengirim menghendaki membuat angka. Maka lebih dahulu harus memberi tanda A sesudah itu baru membuat angkanya.\n\n9. Jika penerima menghendaki supaya kiriman terakhir di ulangi kirimkan kepada pengirim “ INI” dirangkai.\n\n10. Jika pengirim membuat kekeliruan kirimkan huruf “ E” delapan kali.\n\n11. Berita selesai dinyatakan dengan huruf “AR” tunggulah si penerima mengirim huruf “R” artinya ia telah menerima dengan baik.");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
