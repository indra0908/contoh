package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class TkuActivity extends AppCompatActivity {
	
	
	private LinearLayout linear3;
	private ScrollView vscroll5;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private TextView textview3;
	private TextView textview2;
	private TextView textview4;
	private TextView textview1;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.tku);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		vscroll5 = (ScrollView) findViewById(R.id.vscroll5);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview1 = (TextView) findViewById(R.id.textview1);
	}
	private void initializeLogic() {
		textview2.setText("TKU (Tanda Kecakapan Umum) adalah bagian dari sistem tanda kecakapan dalam Gerakan Pramuka di samping TKK (Tanda Kecakapan Khusus). Tanda Kecakapan Umum diberikan setelah seorang anggota Gerakan Pramuka menyelesaikan Syarat-syarat Kecakapan Umum (SKU) dalam tingkatannya masing-masing. Tanda Kecakapan Umum hanya berlaku bagi anggota Pramuka Siaga, Pramuka Penggalang, Pramuka Penegak dan Pramuka Pandega. TKU tidak berlaku bagi sepertiPembina, Andalan dan anggota dewasa lainnya.\n\nBentuk, tingkatan dan pemakaian Pramuka Siaga\n\n• Berbentuk Jajar Genjang miring berwarna dasar hijau dengan gambar “bunga kelapa” berwarna putih.\n\n• TKU Pramuka Siaga terdiri atas: TKU Siaga mula (satu susun), TKU Siaga bantu (dua susun) dan TKU Siaga tata (tiga susun).\n\n• TKU Pramuka Siaga dikenakan di lengan baju sebelah kiri. Pramuka Penggalang\n\n• Berbentuk seperti huruf “V” berwarna dasar merah dengan gambar “bunga kelapa bertangkai tiga” berwarna putih.\n\n• TKU Pramuka Penggalang terdiri atas: TKU Penggalang Ramu (satu susun), TKU Penggalang Rakit (dua susun) dan TKU Penggalang Terap (tiga susun).\n\n• TKU Pramuka Penggalang dikenakan di lengan baju sebelah kiri. Pramuka Penegak\n\n• Berbentuk trapesium berwarna dasar hijau dengan gambar bintang, sepasang tunas kelapa dan tulisan “Bantara” atau “Laksana” berwarna kuning.\n\n• TKU Pramuka Penegak terdiri atas TKU Penegak Bantara (bertuliskan “BANTARA” di bagian bawah tunas kelapa) dan TKU Penegak Laksana (bertuliskan “LAKSANA” di bagian bawah tunas kelapa).\n\n• TKU Pramuka Penegak dikenakan di masing-masing bahu baju seragam pramuka (pundak). Pramuka Pandega\n\n• Berbentuk trapesium berwarna dasar hijau dengan gambar bintang, sepasang tunas kelapa dan tulisan “Pandega” berwarna coklat.\n\n• Tingkatannya hanya satu tingkatan.\n\n• TKU Pramuka Pandega dikenakan di masing-masing bahu baju seragam pramuka (pundak).\n\nPENGGALANG\n\nPenggalang adalah sebuah tingkatan dalam pramuka setelah siaga. Biasanya anggota pramuka tingkat penggalang berusia dari 10-15 tahun. Tingkatan dalam Penggalang Penggalang memiliki beberapa tingkatan dalam golongannya, yaitu : 1. Ramu 2. Rakit 3. Terap 4. Penggalang Garuda Tingkatan Penggalang juga memiliki Syarat Kecakapan Umum (SKU) dan Syarat Kecakapan Khusus (SKK) yang harus dipenuhi untuk mendapatkan kenaikan tingkat atau pendapatkan Tanda Kecapakan Khusus TKK Sistem Kelompok Satuan Terpisah Satuan terkecil dalam Penggalang disebut regu. Setiap regu diketuai oleh seorang Pimpinan Regu (PINRU)yang bertanggung jawab penuh atas regunya tersebut.\n\nDalam Gugus depan Penggalang yang dapat berisi lebih dari satu regu putra/putri, terdapat peserta didik yang bertugas mengkoordinir regu-regu tersebut, peserta didik itu disebut Pratama (untuk putra) atau Pratami (untuk putri). Regu dalam penggalang mempunyai nama-nama untuk mengidentifikasi regu tersebut. Nama Regu Putra diambil dari nama binatang, misalnya harimau, kobra, elang, kalajengking, dan sebagainya. Sedangkan nama regu putri diambil dari nama bunga, semisal anggrek, anyelir, mawar, melati. Trisatya Janji Pramuka Penggalang (Trisatya) berbeda dengan Siaga dan Penegak/Pandega.\n\nBerikut isi Trisatya Penggalang: TRISATYA Demi kehormatanku, aku berjanji akan bersungguh sungguh:\n\n1. Menjalankan kewajibanku kepada Tuhan Yang Maha Esa, Negara Kesatuan Republik Indonesia dan Mengamalkan Pancasila\n\n2. Menolong sesama hidup dan mempersiapkan diri membangun masyarakat\n\n3. Menepati Dasa Dharma Dasa Dharma adalah sepuluh janji seorang pramuka\n\nDASA DHARMA\n\n1. Taqwa kepada tuhan yang maha esa\n\n2. Cinta alam dan kasih sayang kepada manusia\n\n3. Patriot yang sopan dan kesatria\n\n4. Patuh dan suka bermusyawarah\n\n5. Rela menolong dan tabah\n\n6. Rajin,terampil,dan gembira\n\n7. Hemat cermat dan bersahaja\n\n8. Disiplin,berani dan setia\n\n9. Bertanggung jawab dan dapat dipercaya\n\n10. Suci dalam pikiran perkataan dan perbuatan\n\nWARNA DAN ARTI KIASAN TKU\n\n");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
