package Bukusakupramuka.com;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SejarahduniaActivity extends AppCompatActivity {
	
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TextView textview1;
	private TextView textview2;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sejarahdunia);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
	}
	private void initializeLogic() {
		textview2.setText("   Sejarah pramuka di dunia dimulai sejak awal abad 20. Baden Powell dikenal sebagai pemrakarsa gerakan kepramukaan di dunia. Pada tanggal 25 Juli 1907, Baden Powell yang menjabat sebagai Letnan Jenderal tentara Inggris mengadakan perkemahan pramuka di Pulau Brown Sea, Inggris.\n\n   Pada tahun 1908, ia menulis buku ‘Scouting for Boys’ tentang prinsip dasar kepramukaan. Peluncuran buku tersebut menjadi cikal bakal lahirnya gerakan pramuka. Sejak itu kian banyak muncul organisasi kepramukaan. Gerakan pramuka tidak hanya dikenal di Inggris, tapi juga di negara-negara lain di dunia.\n\n   Awalnya gerakan pramuka hanya didominasi laki-laki, namun sejak tahun 1912, muncul organisasi pramuka ‘Girl Guides’ yang didirikan dengan bantuan adik perempuan Baden Powell, Agnes. Organisasi kepramukaan perempuan ini kemudian dilanjutkan oleh istri Baden Powell.\n\n   Organisasi kepramukaan di dunia terus berkembang. Pada tahun 1916, berdiri organisasi pramuka usia siaga bernama CUB atau anak serigala, yang dilengkapi buku panduan kegiatan merujuk pada buku The Jungle Book. Di tahun 1918, Powell mendirikan ‘Rover Scout’ untuk kelompok remaja usia 17 tahun.\n\n   Pada tahun 1922, Baden Powell menerbitkan buku ‘Rovering to Success’ atau ‘Mengembara Menuju Sukses’. Buku tersebut menceritakan seorang pemuda yang terus mengayuh sampan hingga akhirnya menuju pantai bahagia. Buku tersebut kian menginspirasi berkembangnya gerakan kepramukaan di dunia saat itu.\n\n   Pada 30 Juli sampai 8 Agustus 1920, untuk pertama kalinya diadakan Jambore Dunia. Kegiatan ini pertama diadakan di Olympia Hall, London, dengan dihadiri sekitar 8000 anggota pramuka dari 34 negara yang hadir. Di acara itu, Baden Powell dinobatkan sebagai Chief Scout of the World atau Bapak Pandu Sedunia.\n\n   Masih pada tahun yang sama, dibentuklah Dewan Internasional Organisasi Pramuka yang beranggotakan 9 orang. Kota London ditetapkan sebagai kantor kesektariatan Pramuka sedunia, meski kemudian berpindah ke Ottawa, Kanada pada tahun 1958 serta ke Geneva, Swiss pada tahun 1968.");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
